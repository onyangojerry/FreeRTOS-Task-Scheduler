/* 
 * File:   vP2Task.h
 *
 * Author: Jennifer W DesCombes
 *         Pomona College
 * 
 * Created on April 2, 2025, 10:40 AM
 */

#ifndef VP2TASK_H
#define	VP2TASK_H

#ifdef	__cplusplus
extern "C" {
#endif

//
// Type Declarations
//

// NOTE: do not access the individual elements of the structure
// as the type, name, and location of these elements may change as
// improvements are made to the code. Use the access methods to
// access information about the de-bounced pushbutton.


//
// Method Definitions
//

void vP2TaskInit( );                // Initialization of Task Global Variables
void vP2Task(void *pvParameters);   // Priority 2 Task



#ifdef	__cplusplus
}
#endif

#endif	/* VP2TASK_H */

