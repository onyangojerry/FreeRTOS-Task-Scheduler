/*******************************************************************************
  VP2 Task Source File

  Company:
    Jennifer W DesCombes
    Pomona College

  File Name:
    vP2Task.c

  Summary:
    This file contains the lowest priority task for a project. It is designed
    to be always runnable.

  Description:
    This task toggles an IO pin so that a measurement of the system utilization
    can be performed based on when the signal is not toggling (and thus the 
    system is doing something useful).
  
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <string.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "vP2Task.h"                    // definitions for vP1Task
#include "pwm/pwm.h"                    // definitions for pwm
#include "globalsCSCI181RT.h"           // definitions for system globals

#include "FreeRTOS.h"                   // SYS definitions for FreeRTOS
#include "task.h"                       // SYS definitions for Tasks
#include "semphr.h"                     // SYS definitions for Semaphores
// In globalsCSCI181RT.h
#include "queue.h"


// *****************************************************************************
// *****************************************************************************
// Section: dummyTask Entry Point
// *****************************************************************************
// *****************************************************************************

//
// Type Declarations
//


//
// Global Data Declarations
//
extern QueueHandle_t xTaskCommQueue;  // Declaration only

//
// Global Defines
//

int gIntInputSignalState;


//
// Method Definitions
//
 
void monitorGPIO1PinState( void );


//
// Methods
//

//
// Initialization of Task Global Variables
//
void vP2TaskInit( )                
{
    gIntInputSignalState = 1;
}



#ifndef USE_INPUT_COMPARE

/*
//  Task Priority 2 (P2)
//
//    Monitor the external input via task polling
*/
void vP2Task(void *pvParameters)
{
    
    //
    // Task global data and hardware initialization
    //
    TaskMessage msg;
    msg.senderID = 2;  // Replace with task number: 1, 2, or 3
    msg.recipientID = 99;
    strncpy(msg.payload, "Message from P2", sizeof(msg.payload));
    msg.payload[sizeof(msg.payload) - 1] = '\0';

    // Delay a small amount of time to offset simultaneously task startup
    vTaskDelay(pdMS_TO_TICKS(3));

    while( true )
    {

        // Delay five milliseconds until next activation of task
        vTaskDelay(pdMS_TO_TICKS(5));

        // Monitor and display the state of GPIO1
        monitorGPIO1PinState();
        
        xQueueSend(xTaskCommQueue, &msg, 0);

       
    }
}


/*
//  Monitor and display the pin state of GPIO1 on J105-5
*/
void monitorGPIO1PinState( void )
{
    
    // Monitor the state of GPIO1 on J105
    if (GPIO_PinRead( DigitalGPIO_1 ) == 0) 
    {
        if (gIntInputSignalState != 0)
        {
            gIntInputSignalState = 0;
            GPIO_PinSet( LED_2 );    // Led 2  NOTE: LED is low true logic
        }
    }
    else
    {
        if (gIntInputSignalState != 1)
        {
            gIntInputSignalState = 1;
            GPIO_PinClear( LED_2 );    // Led 2  NOTE: LED is low true logic
        }
    }
}

#else

/*
//  Task Priority 2 (P2)
//
//    Monitor the external input via input compare hardware
*/
void vP2Task(void *pvParameters)
{
    
    //
    //  Task global data and hardware initialization
    //

    // Add your software here to control via input compare and 
    // interrupt.
    
    while( true )
    {

        // Delay five milliseconds until next activation of task
        vTaskDelay(pdMS_TO_TICKS(5));
       
    }
}

#endif


/*******************************************************************************
 End of File
*/
