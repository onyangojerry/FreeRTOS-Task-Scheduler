/*******************************************************************************
  VP1 Task Source File

  Company:
    Jennifer W DesCombes
    Pomona College

  File Name:
    vP1Task.c

  Summary:
    This file contains the lowest priority task for a project. It is designed
    to be always runnable.

  Description:
    This task toggles an IO pin so that a measurement of the system utilization
    can be performed based on when the signal is not toggling (and thus the 
    system is doing something useful).
  
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <string.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "vP1Task.h"                    // definitions for vP1Task
#include "pwm/pwm.h"                    // definitions for pwm
#include "globalsCSCI181RT.h"           // definitions for system globals

#include "FreeRTOS.h"                   // SYS definitions for FreeRTOS
#include "task.h"                       // SYS definitions for Tasks
#include "semphr.h"                     // SYS definitions for Semaphores
// In globalsCSCI181RT.h
#include "queue.h"


// *****************************************************************************
// *****************************************************************************
// Section: dummyTask Entry Point
// *****************************************************************************
// *****************************************************************************

//
// Type Declarations
//


//
// Global Data Declarations
//
extern QueueHandle_t xTaskCommQueue;  // Declaration only

//
// Global Defines
//


//
// Method Definitions
//
 

//
// Methods
//


/*
//  Highest Priority Task (P1)
*/
void vP1Task(void *pvParameters)
{
    
    //
    // Task global data and hardware initialization
    //
    TaskMessage msg;
    msg.senderID = 1;  // Replace with task number: 1, 2, or 3
    msg.recipientID = 99;
    strncpy(msg.payload, "Message from PX", sizeof(msg.payload));
    msg.payload[sizeof(msg.payload) - 1] = '\0';
    
    
    while( true )
    {
    
        // Delay one millisecond until next activation of task
        vTaskDelay(pdMS_TO_TICKS(1));

        // Toggle Task Pin to demonstrate activity
        GPIO_PinToggle(P1TaskPin);
        
        // PWM of LED3 based on gIntLevelControl
        if (pwmProcessing( gIntLevelControl, &gPWMLED3 ) == ledOn)
        {
            GPIO_PinClear( LED_3 );    // Turn on Led 3  NOTE: LED is low true logic
        }
        else
        {
            GPIO_PinSet( LED_3 );    // Turn off Led 3  NOTE: LED is low true logic
        }

        // The following test code turns off the multicolor LED at the same 
        // intensity as LED3 (although light output may vary). A color shift has
        // been added (see green) to make things interesting.)
        if (pwmProcessing( gIntLevelControl, &gPWMLEDRGB ) == ledOn)
        {
            GPIO_PinClear( LED_Red );    // Led Red  NOTE: LED is low true logic
            GPIO_PinSet( LED_Green );  // Led Green  NOTE: LED is low true logic
            GPIO_PinClear( LED_Blue );   // Led Blue  NOTE: LED is low true logic
        }
        else
        {
            GPIO_PinSet( LED_Red );    // Led Red  NOTE: LED is low true logic
            GPIO_PinClear( LED_Green );  // Led Green  NOTE: LED is low true logic
            GPIO_PinSet( LED_Blue );   // Led Blue  NOTE: LED is low true logic
        }

        // Other Processing
        xQueueSend(xTaskCommQueue, &msg, 0);


    }
}


/*******************************************************************************
 End of File
*/
