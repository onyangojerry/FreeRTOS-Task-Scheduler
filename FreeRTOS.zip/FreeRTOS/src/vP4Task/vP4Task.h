/* 
 * File:   vP3Task.h
 *
 * Author: Jerry Onyango
 *         Pomona College
 * 
 * Created on April 2, 2025, 10:40 AM
 */

#ifndef VP4TASK_H
#define	VP4TASK_H

#ifdef	__cplusplus
extern "C" {
#endif

//
// Type Declarations
//

// NOTE: do not access the individual elements of the structure
// as the type, name, and location of these elements may change as
// improvements are made to the code. Use the access methods to
// access information about the de-bounced pushbutton.


//
// Method Definitions
//

void vP4Task(void *pvParameters);   // Priority 3 Task



#ifdef	__cplusplus
}
#endif

#endif	/* VP4TASK_H */

