/*******************************************************************************
  VP3 Task Source File

  Company:
    Jennifer W DesCombes
    Pomona College

  File Name:
    vP4Task.c

  Summary:
    This file contains the lowest priority task for a project. It is designed
    to be always runnable.

  Description:
    This task toggles an IO pin so that a measurement of the system utilization
    can be performed based on when the signal is not toggling (and thus the 
    system is doing something useful).
  
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <string.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "vP4Task.h"                    // definitions for vP1Task
#include "pwm/pwm.h"                    // definitions for pwm
#include "globalsCSCI181RT.h"           // definitions for system globals

#include "FreeRTOS.h"                   // SYS definitions for FreeRTOS
#include "task.h"                       // SYS definitions for Tasks
#include "semphr.h"                     // SYS definitions for Semaphores
// In globalsCSCI181RT.h
#include "queue.h"

extern QueueHandle_t xTaskCommQueue;  // Declaration only
// *****************************************************************************
// *****************************************************************************
// Section: dummyTask Entry Point
// *****************************************************************************
// *****************************************************************************

//
// Type Declarations
//
/*
//  Task Priority 4 (P4)
//
//    Toggle the heartbeat LED - 1 second rate
*/
void vP4Task(void *pvParameters)
{
    TaskMessage msg;
    msg.senderID = 4;
    msg.recipientID = 99;
    strncpy(msg.payload, "Pulse from P4", sizeof(msg.payload));
    msg.payload[sizeof(msg.payload) - 1] = '\0';
    //
    // Task global data and hardware initialization
    //
 
    // Delay a small amount of time to offset simultaneously task startup
    vTaskDelay(pdMS_TO_TICKS(7));

    while( true )
    {   
        
        GPIO_PinInputEnable(PushButton_1);
    

        // Delay one second until next activation of task
//        vTaskDelay(pdMS_TO_TICKS(1000));
//
//        // Toggle heart beat LED (LED1)
//        GPIO_PinToggle( LED_1 );    // Led 1  NOTE: LED is low true logic
        
        vTaskDelay(pdMS_TO_TICKS(800));
        GPIO_PinClear(LED_1);
        vTaskDelay(pdMS_TO_TICKS(200));
        GPIO_PinSet(LED_1);
        
        // Send message to queue
        xQueueSend(xTaskCommQueue, &msg, 0);
    
    }
}


/*******************************************************************************
 End of File
*/
