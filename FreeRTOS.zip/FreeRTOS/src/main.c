/*******************************************************************************
  Main Source File

  Copyright 2025 Pomona College, All Rights Reserved
      Special Thanks to Neil
 

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "debounce/debounce.h"          // definitions for debounce
#include "pwm/pwm.h"                    // definitions for pwm
#include "vP1Task/vP1Task.h"                    // definitions for vP1Task
#include "vP2Task/vP2Task.h"                    // definitions for vP2Task
#include "vP3Task/vP3Task.h"                    // definitions for vP3Task
#include "vP4Task/vP4Task.h"                    // definitions for vP4Task
#include "vP5Task/vP5Task.h"
#include "dummyTask/dummyTask.h"        // definitions for the dummyTask
#include "globalsCSCI181RT.h"           // definitions for system globals

#include "FreeRTOS.h"                   // SYS definitions for FreeRTOS
#include "task.h"                       // SYS definitions for Tasks
#include "semphr.h"                     // SYS definitions for Semaphores


//
// Type Declarations
//
    

//
// Global Data Declarations
//

// Refer to globalsCSCI181.h and globalsCSCI181.c


//
// Global Defines
//


// The following define determines if the external input
// is monitored via software or via the input compare hardware
// and its corresponding interrupt.
//
//#define USE_INPUT_COMPARE
//


//
// Method Definitions
//


void vP4Task(void *pvParameters);     // Task Priority 4 (P4)


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************



int main ( void )
{
    
    // Initialize global data
    initGlobalData( );
    
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    
    xTaskCommQueue = xQueueCreate(10, sizeof(TaskMessage));
    if (xTaskCommQueue == NULL) {
        // handle error ? you can blink LED, log over UART, or just hang
        while (1);  // simple fail-safe
    }
    // Create Tasks within the OS
    
    xTaskCreate(vP1Task,         // Task function
                "P1Task",        // Name of the task
                1024,            // Stack size (in words, not bytes)
                NULL,            // Task parameter
                6,               // Task priority (1 is lowest priority)
                NULL);           // Task handle (optional)
    
    xTaskCreate(vP2Task,         // Task function
                "P2Task",        // Name of the task
                1024,            // Stack size (in words, not bytes)
                NULL,            // Task parameter
                5,               // Task priority (1 is lowest priority)
                NULL);           // Task handle (optional)
    
    xTaskCreate(vP3Task,         // Task function
                "P3Task",        // Name of the task
                1024,            // Stack size (in words, not bytes)
                NULL,            // Task parameter
                4,               // Task priority (1 is lowest priority)
                NULL);           // Task handle (optional)
    
    xTaskCreate(vP4Task,         // Task function
                "P4Task",        // Name of the task
                1024,            // Stack size (in words, not bytes)
                NULL,            // Task parameter
                3,               // Task priority (1 is lowest priority)
                NULL);           // Task handle (optional)
    
    xTaskCreate(vP5Task,         // task function
                "vP5Task",       // Name of the Task
                1024,            // stack size (in words not bytes)
                NULL,            // task parameter
                2,               // task priority ( 1 is lowest priority)
                NULL);           // task handle (optional)
    
    xTaskCreate(dummyTask,         // Task function
                "DummyTask",       // Name of the task
                1024,              // Stack size (in words, not bytes)
                NULL,              // Task parameter
                1,                 // Task priority (1 is lowest priority)
                NULL);             // Task handle (optional)
    
    // Initialize Tasks
    vP2TaskInit( ); 
    
    // Start Tasks
    vTaskStartScheduler();

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

