/*******************************************************************************
  Dummy Task Source File

  Company:
 Jerry Onyango
    Pomona College

  File Name:
    dummyTask.c

  Summary:
    This file contains the lowest priority task for a project. It is designed
    to be always runnable.

  Description:
    This task toggles an IO pin so that a measurement of the system utilization
    can be performed based on when the signal is not toggling (and thus the 
    system is doing something useful).
  
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <string.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "dummyTask.h"                   // definitions for debounce
#include "globalsCSCI181RT.h"           // 
#include "FreeRTOS.h"                   // SYS definitions for FreeRTOS
#include "task.h"                       // SYS definitions for Tasks
#include "semphr.h"                     // SYS definitions for Semaphores
// In globalsCSCI181RT.h
#include "queue.h"


// *****************************************************************************
// *****************************************************************************
// Section: dummyTask Entry Point
// *****************************************************************************
// *****************************************************************************

//
// Type Declarations
//
uint8_t bufferLineBreak[] = "\r\n";
uint8_t task[] = "Running dummy task\r\n";

//
// Global Data Declarations
//


//
// Global Defines
//


//
// Method Definitions
//
 

//
// Methods
//


/*
//  Lowest Priority Task
 * 
*/

void dummyTask(void *pvParameters)
{
    uint8_t rxChar; 

    TaskMessage msg;
    char logBuffer[64];
    
    // Default blink intervals
    uint32_t onTime = 500;
    uint32_t offTime = 500;
    
    UART6_Write((uint8_t *)"Dummy Task Ready. Type 1-4 for LED control\r\n", 44);

    
       while (true)
    {
        // 1. Check for new message from other tasks
        if (xQueueReceive(xTaskCommQueue, &msg, 0) == pdPASS)
        {
            snprintf(logBuffer, sizeof(logBuffer), "Received from P%d: %s\r\n", msg.senderID, msg.payload);
            UART6_Write((uint8_t *)logBuffer, strlen(logBuffer));
        }

        // 2. Check for keyboard input over UART
        if (UART6_Read(&rxChar, 1) > 0)
        {
            switch (rxChar)
            {
                case '1': onTime = 200; offTime = 800;
                          UART6_Write((uint8_t *)"Set to 200ms ON / 800ms OFF\r\n", 30); break;
                case '2': onTime = 500; offTime = 500;
                          UART6_Write((uint8_t *)"Set to 500ms ON / 500ms OFF\r\n", 30); break;
                case '3': onTime = 400; offTime = 1600;
                          UART6_Write((uint8_t *)"Set to 400ms ON / 1600ms OFF\r\n", 31); break;
                case '4': onTime = 5000; offTime = 5000;
                          UART6_Write((uint8_t *)"Set to 1000ms ON / 1000ms OFF\r\n", 32); break;
                default:
                          UART6_Write((uint8_t *)"Invalid command. Use 1-4\r\n", 27); break;
            }
        }

        // 3. Blink dummy task pin according to current timing
        GPIO_PinSet(LED_1);
        vTaskDelay(pdMS_TO_TICKS(onTime));
        GPIO_PinClear(LED_1);
        vTaskDelay(pdMS_TO_TICKS(offTime));
    }
    
    
//    while (true)
//    {
//        if (xQueueReceive(xTaskCommQueue, &msg, portMAX_DELAY) == pdPASS)
//        {
//            // Build UART message
//            snprintf(logBuffer, sizeof(logBuffer), "Received from P%d: %s\r\n", msg.senderID, msg.payload);
//            UART6_Write((uint8_t *)logBuffer, strlen(logBuffer));
//
//            // Optionally, blink LED based on senderID
//            switch (msg.senderID)
//            {
//                case 1: GPIO_PinToggle(LED_Red); break;
//                case 2: GPIO_PinToggle(LED_Green); break;
//                case 3: GPIO_PinToggle(LED_Blue); break;
//                case 4: GPIO_PinToggle(LED_2); break;
//                case 5: GPIO_PinToggle(LED_3); break;
//                default: break;
//            }
//        }
//    }
}
//void dummyTask(void *pvParameters)
//{
//    
//    //
//    // Task global data and hardware initialization
//    //
//    TaskMessage msg;
//    char logBuffer[64];
//
//    while( true )
//    {
//        
//        // Test Code to mostly disable this task
//        //vTaskDelay(pdMS_TO_TICKS(10000));
//
//        // Toggle Dummy Task Pin On & Off Continuously when executing
//        GPIO_PinSet( DummyTaskPin );
//        UART6_Write(&task[0], sizeof(task));
//        GPIO_PinClear( DummyTaskPin );
//    }
//}





/*******************************************************************************
 End of File
*/
