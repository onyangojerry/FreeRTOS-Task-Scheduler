/*******************************************************************************
  VP3 Task Source File

  Company:
    Jennifer W DesCombes
    Pomona College

  File Name:
    vP3Task.c

  Summary:
    This file contains the lowest priority task for a project. It is designed
    to be always runnable.

  Description:
    This task toggles an IO pin so that a measurement of the system utilization
    can be performed based on when the signal is not toggling (and thus the 
    system is doing something useful).
  
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <string.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "vP3Task.h"                    // definitions for vP1Task
#include "pwm/pwm.h"                    // definitions for pwm
#include "globalsCSCI181RT.h"           // definitions for system globals

#include "FreeRTOS.h"                   // SYS definitions for FreeRTOS
#include "task.h"                       // SYS definitions for Tasks
#include "semphr.h"                     // SYS definitions for Semaphores
// In globalsCSCI181RT.h
#include "queue.h"


// *****************************************************************************
// *****************************************************************************
// Section: dummyTask Entry Point
// *****************************************************************************
// *****************************************************************************

//
// Type Declarations
//

//uint8_t bufferLineBreak[] = "\r\n";
//uint8_t task[] = "Running task 3\r\n";
//
// Global Data Declarations
//

extern QueueHandle_t xTaskCommQueue;  // Declaration only
//
// Global Defines
//


//
// Method Definitions
//
 
void levelLED3Adjust( void );


//
// Methods
//

/*
//  Task Priority 3 (P3)
//
//    Toggle the heartbeat LED - 1 second rate
*/
void vP3Task(void *pvParameters)
{
    
    //
    //  Task global data and hardware initialization
    //
    TaskMessage msg;
    msg.senderID = 3;  // Replace with task number: 1, 2, or 3
    msg.recipientID = 99;
    strncpy(msg.payload, "Message from P3", sizeof(msg.payload));
    msg.payload[sizeof(msg.payload) - 1] = '\0';

    // Delay a small amount of time to offset simultaneously task startup
    vTaskDelay(pdMS_TO_TICKS(5));

    while( true )
    {
        //UART6_Write(&task[0], sizeof(task));
        // Delay ten millisecond until next activation of task
        vTaskDelay(pdMS_TO_TICKS(10));

        // Toggle Task Pin to demonstrate activity
        GPIO_PinToggle(LED_3);
        
        
        // De-bounce pushbutton inputs
        debounceInput( GPIO_PinRead( PushButton_1 ), &gDebounceButton1 );
        debounceInput( GPIO_PinRead( PushButton_2 ), &gDebounceButton2 );
        debounceInput( GPIO_PinRead( PushButton_3 ), &gDebounceButton3 );
        debounceInput( GPIO_PinRead( PushButton_4 ), &gDebounceButton4 );

        // Adjust the level of LED3
        levelLED3Adjust();

        // Demonstrate operation of button 1
        if (getDebounceValue( &gDebounceButton1 ) == 0)  // NOTE: button pushed reads zero, low true logic
        {
            GPIO_PinClear( LED_3 );    // Led 1  NOTE: LED is low true logic
        }
        
        xQueueSend(xTaskCommQueue, &msg, 0);


    }
}


/*
//  Adjust the relative input level on LED 3
*/
void levelLED3Adjust( void )
{
    
    
    // Validate level data
    if (gIntLevelControl < levelMinCount)
    {
        gIntLevelControl = levelMinCount;
    }
    else
    {
        if (gIntLevelControl > levelMaxCount)
        {
            gIntLevelControl = levelMaxCount;
        }
    }
    
    // Decrease level by pressing button 3
    if (getDebounceStatusChange( &gDebounceButton3 ) == true)
    {
        if (getDebounceValue( &gDebounceButton3 ) == 0)  // NOTE: button pushed reads zero, low true logic
        {
            gIntLevelControl -= 1;
            if (gIntLevelControl < levelMinCount)
            {
                gIntLevelControl = levelMinCount;
            }
        }
    }
    
    // Increase level by pressing button 4
    if (getDebounceStatusChange( &gDebounceButton4 ) == true)
    {
        if (getDebounceValue( &gDebounceButton4 ) == 0)  // NOTE: button pushed reads zero, low true logic
        {
            gIntLevelControl += 1;
            if (gIntLevelControl > levelMaxCount)
            {
                gIntLevelControl = levelMaxCount;
                
            }
        }
    }
    
}



/*******************************************************************************
 End of File
*/
