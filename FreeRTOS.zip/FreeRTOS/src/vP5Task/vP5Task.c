/*******************************************************************************
  VP5 Task Source File

  Company:
    Pomona College

  File Name:
    vP5Task.c

  Summary:
    Task 5 handles some periodic GPIO activity or computation.

  Description:
    This task toggles a dedicated pin and optionally performs background logic.
*******************************************************************************/

#include <stddef.h>
#include <string.h>
#include <stdbool.h>
#include "definitions.h"                // SYS function prototypes
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "vP5Task.h"                    // Task header
#include "pwm/pwm.h"                    // Optional PWM utilities
#include "globalsCSCI181RT.h"           // Global data
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
// In globalsCSCI181RT.h
#include "queue.h"

extern QueueHandle_t xTaskCommQueue;  // Declaration only


// *****************************************************************************
// Task Priority 5 (P5)
// Toggles a pin and performs basic periodic activity every 20 ms
// *****************************************************************************

void vP5Task(void *pvParameters)
{   
    // Prepare a message struct
    TaskMessage msg;
    msg.senderID = 5;               // ID for vP5Task
    msg.recipientID = 99;           // 99 = broadcast, or dummyTask
    strcpy(msg.payload, "Hello from P5");
    
    // Initial delay to stagger startup
    vTaskDelay(pdMS_TO_TICKS(50));

    while (true)
    {
        // Delay 20 milliseconds
        vTaskDelay(pdMS_TO_TICKS(100));

        // Toggle a pin to show activity (e.g., debug or profiling)
        GPIO_PinToggle(LED_2);

        // Optional: Add custom logic here
        // Example: pulse an LED, check a flag, log data, etc.
        // Send message to the queue
        if (xQueueSend(xTaskCommQueue, &msg, 0) != pdPASS)
        {
            // Queue full ? optionally handle this (e.g., blink error LED)
            GPIO_PinToggle(LED_3);
        }
    }
}


/*******************************************************************************
 End of File
*/
