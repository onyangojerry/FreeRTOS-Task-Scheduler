/*******************************************************************************
  System Globals for CSCI 181RT

  File Name:
    globalsCSCI181RT.h

  Summary:
    project system globals for CSCI 181RT.

  Description:
    This file contains the system-wide (global) variables for a project
    used in Pomona College CSCI 181RT.

 *******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2024 Jennifer DesCombes, all rights reserved.
********************************************************************************/


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "globalsCSCI181RT.h"           // definitions for system globals
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "FreeRTOS.h"
#include "queue.h"


// Global data used by fiveMSProcessing()
int gIntLevelControl;

// Global data used by PWM code
pwmStruct gPWMLED3;
pwmStruct gPWMLEDRGB;

// Global data used by button de-bounce code
debounceStruct gDebounceButton1;
debounceStruct gDebounceButton2;
debounceStruct gDebounceButton3;
debounceStruct gDebounceButton4;


QueueHandle_t xTaskCommQueue; // queue definitions





//
// Initialize Global Data
void initGlobalData( )
{
    
    gIntLevelControl = levelInitialCount;
    
    initPWM( &gPWMLED3,               // location of the data structure
             levelMaxCount,           // Maximum value of the PWM output
             levelMinCount );         // Minimum value of the PWM output
    initPWM( &gPWMLEDRGB,            // location of the data structure
             levelMaxCount,           // Maximum value of the PWM output
             levelMinCount );         // Minimum value of the PWM output          
    
    initDebounceInput( &gDebounceButton1,     // Pointer to de-bounce data structure
                       3 );                   // Number of sequential states for de-bounce
    initDebounceInput( &gDebounceButton2,     // Pointer to de-bounce data structure
                       3 );                   // Number of sequential states for de-bounce
    initDebounceInput( &gDebounceButton3,     // Pointer to de-bounce data structure
                       3 );                   // Number of sequential states for de-bounce
    initDebounceInput( &gDebounceButton4,     // Pointer to de-bounce data structure
                       3 );                   // Number of sequential states for de-bounce
    
}



/*******************************************************************************
 End of File
*/

