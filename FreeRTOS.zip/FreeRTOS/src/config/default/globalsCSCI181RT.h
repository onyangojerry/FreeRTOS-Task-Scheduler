/*******************************************************************************
  System Globals for CSCI 181RT

  File Name:
    globalsCSCI181RT.h

  Summary:
    project system globals for CSCI 181RT.

  Description:
    This file contains the system-wide (global) variables for a project
    used in Pomona College CSCI 181RT.

 *******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2025 Jennifer DesCombes, all rights reserved.
********************************************************************************/

#include "peripheral/gpio/plib_gpio.h"
#include "definitionsCSCI181RT.h"       // SYS definitions for CSCI 181RT
#include "debounce/debounce.h"          // definitions for debounce
#include "pwm/pwm.h"                    // definitions for pwm
#include "FreeRTOS.h"
#include "queue.h"


#ifndef GLOBALSCSCI181RT_H
#define GLOBALSCSCI181RT_H

// changed global names from GLOBALSSCSCI181RT_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END

//
// Evaluation Board Information
//

typedef struct {
    uint8_t senderID;
    uint8_t recipientID;
    char payload[16];
} TaskMessage;

extern QueueHandle_t xTaskCommQueue;

// Global data used by various tasks()
extern int gIntLevelControl;

// Global data used by PWM code
extern pwmStruct gPWMLED3;
extern pwmStruct gPWMLEDRGB;

// Global data used by button de-bounce code
extern debounceStruct gDebounceButton1;
extern debounceStruct gDebounceButton2;
extern debounceStruct gDebounceButton3;
extern debounceStruct gDebounceButton4;


//
// Method Definitions
//

void initGlobalData( );


// *****************************************************************************
// *****************************************************************************
// Section: extern declarations
// *****************************************************************************
// *****************************************************************************




//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* GLOBALSSCSCI181RT_H */
/*******************************************************************************
 End of File
*/

